<?php

namespace BackupMigrate\Drupal\Environment;

use BackupMigrate\Core\Environment\EnvironmentBase;

/**
 * Class DrupalEnvironment.
 *
 * @package BackupMigrate\Drupal\Environment
 */
class DrupalEnvironment extends EnvironmentBase {}
