ABOUT BARTIK
------------

Bartik is the default theme for Drupal 8.  It is a flexible, recolorable theme
with a responsive and mobile-first layout, supporting 16 regions.

The Bartik theme is named after Jean Bartik, one of the original programmers
for the ENIAC computer.

This theme is not intended to be used as a base theme.

To read more about the Bartik theme please see:
https://www.drupal.org/docs/8/core/themes/bartik-theme

ABOUT DRUPAL THEMING
--------------------

See https://www.drupal.org/docs/8/theming for more information on Drupal
theming.
