(function ($) {
	'use strict';
    
$("body").addClass( "tt-dark-style" );
    
})(jQuery); 
