(function ($) {
	'use strict';
    
$("body").removeClass("tt-boxed");
    
})(jQuery); 
